function [y] = func(x)
%func oblicza wartosc funkcji
%   x - argument
y = 2 * cos(x/2);
end