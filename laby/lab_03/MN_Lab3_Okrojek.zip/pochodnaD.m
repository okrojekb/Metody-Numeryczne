function [pochodna] = pochodnaD(x)
%pochodnaD wynacza dokladna wartosc pochodnej
%  f - funkcja

pochodna = -sin(x/2);

end