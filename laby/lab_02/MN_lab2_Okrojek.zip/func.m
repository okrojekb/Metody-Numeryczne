function [y] = func(x)
%func wyznacza dokladna wartosc sin(x)

y = sin(x);
end