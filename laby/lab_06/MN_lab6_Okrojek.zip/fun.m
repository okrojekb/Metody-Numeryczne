function [y] = fun(x)
%fun wyznacza wartosc funkcji sin(x)*log(x)
%   x - argumenty
y = sin(x).*log(x);
end